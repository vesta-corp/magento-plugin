<?php
/**
 * Form File Doc Comment
 *
 * PHP version 7.0
 * @category  Payment
 * @package   Vesta Corporation
 * @link      https://trustvesta.com
 * @author    Chetu Team
 */
namespace Vesta\Payment\Block;

use Magento\Payment\Block\Form\Cc;

/**
 * Form Class Doc Comment
 *
 * PHP version 7.0
 * @category  Payment
 * @package   Vesta Corporation
 * @link      https://trustvesta.com
 * @author    Chetu Team
 */
class Form extends Cc
{
    
}
