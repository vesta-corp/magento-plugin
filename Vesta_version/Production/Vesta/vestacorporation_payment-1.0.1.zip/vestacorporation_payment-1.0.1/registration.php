<?php

/**
 * Registration File Doc Comment
 *
 * PHP version 7.0
 *
 * @category  Payment
 * @package   Vesta Corporation
 * @link      https://trustvesta.com
 * @author    Chetu Team
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Vesta_Payment',
    __DIR__
);
